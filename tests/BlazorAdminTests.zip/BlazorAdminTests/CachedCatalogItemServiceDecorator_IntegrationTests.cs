﻿//using Microsoft.VisualStudio.TestPlatform.TestHost;
//using Microsoft.AspNetCore.Mvc.Testing;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.AspNetCore.Hosting;
using Xunit;
using System.Threading.Tasks;

namespace BlazorAdminTests;

public class CachedCatalogItemServiceDecorator_IntegrationTests : IClassFixture<BlazorAppFactory>
{
    private readonly BlazorAppFactory factory;

    public CachedCatalogItemServiceDecorator_IntegrationTests(BlazorAppFactory factory)
    {
        this.factory = factory;
    }

    [Fact]
    public async Task WebApplication()
    {
        // Arrange
        var client = factory.CreateClient();

        // Act
        var response = await client.GetAsync("/");
    }
}
