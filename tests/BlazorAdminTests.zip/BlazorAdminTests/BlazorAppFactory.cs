﻿using Microsoft.AspNetCore.Hosting;
//using Microsoft.AspNetCore.Mvc.Testing;
//using Microsoft.VisualStudio.TestPlatform.TestHost;
//using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
//using Microsoft.AspNetCore.Mvc.Testing;

namespace BlazorAdminTests;
public class BlazorAppFactory : WebApplicationFactory<BlazorAdmin.Program>
{
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            // Add any necessary service configurations or overrides here
            // Example: services.AddSingleton<MyInterface, MyImplementation>();
        });
    }
}
